# Fincheck

## Done
* ERD - Lucid
* NEST Js
* ORM - Prisma 

## To do (Fora do curso)
* Criar CRUD de categorias
* Criar transferência entre contas

## Atenção
Instalar a extensão do prisma

Config Prisma:
"[prisma]": {
"editor.defaultFormatter": "Prisma.prisma",
"editor.formatOnSave": true
},