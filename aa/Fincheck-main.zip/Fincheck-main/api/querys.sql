docker start pg

docker exec -it pg bash 

psql -U root

\l 

--------------------

CREATE DATABASE fincheck;

